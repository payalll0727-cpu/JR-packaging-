# Real product intake — J.R. Paper Tube & Packaging (started 2026-10-17, units confirmed 2026-10-17)
Source: Payal's messages. UNITS FINAL: patty roll per pc, paper tube per pc, BOPP bag per packet (1000 pcs each), carton bag per kg, clip per kg.

## 1. Paper Tube / Danda — PHOTO MISSING (resend needed)
- Variants (quality = paper GSM):
  - 200g — ₹7.20 / pc
  - 250g — ₹9.00 / pc
  - 300g — ₹10.80 / pc
- Specs: Length 47 inch, Diameter 25mm
- Customization available → link to Get Quote flow
- Unit: per piece (assumed — confirm)
- Photos: public/img/paper-tube-danda.jpg saved (bundle shot — confirmed as THE product photo 2026-10-17); the earlier single-roll photo didn't save, not needed anymore

## 2. Parcel Packing Clip
- Price: ₹68 (unit unclear — per piece assumed; confirm)
- Photo: public/img/parcel-packing-clip.jpg saved

## 3. BOPP Bag (self-seal, crystal clear)
- Size: 12 × 17 × 18 (inches assumed)
- Variants (quality = thickness in microns):
  - 25m — ₹1360
  - 36m — ₹1850
  - 40m — ₹1980
  - 51m — ₹2350
- Unit: likely per kg — CONFIRM (bags usually sold per kg)
- Photo: public/img/bopp-bag.jpg saved

## 4. Carton Bag / Parcel Bag (blue poly liner bag)
- Quality: Blue color
- Rate: ₹78 (unit unclear — per kg or per piece; confirm)
- Photo: public/img/carton-bag-parcel.jpg saved

## 5. Patty Roll / Box Strapping Roll
- Quality: Pure Virgin
- Rate: ₹280 (unit unclear — per roll or per kg; confirm)
- Photo: public/img/patty-roll-strapping.jpg saved
