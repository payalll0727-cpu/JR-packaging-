/**
 * J.R. Paper Tube & Packaging — site configuration
 * =================================================
 * ⚠️  BEFORE GOING LIVE, replace every value marked PLACEHOLDER below.
 * See README.md "Go-live checklist" for the full list.
 */

module.exports = {
  business: {
    name: "J.R. Paper Tube & Packaging",
    owner: "Jetharam Choudhary",
    address: "4/2128, Kagjini Chawl, N.T.M. Sahara Darwaja, Surat",
    phones: ["93775 13044", "99988 20009", "93776 67750"],
    // WhatsApp help button number, digits only with country code. Clearly marked config value.
    whatsapp: "919377513044",
    // PLACEHOLDER — business GSTIN is not known. Leave "" until the owner provides it;
    // the invoice shows "—" when unset.
    gstin: "",
    // GST rate (%) applied on invoices. SAMPLE/adjustable — confirm with the owner's CA.
    gst_rate: 18,
  },

  razorpay: {
    // PLACEHOLDER — replace with the business's LIVE Razorpay credentials
    // from the Razorpay Dashboard (Settings → API Keys) before going live.
    key_id: "rzp_test_PLACEHOLDER",
    key_secret: "PLACEHOLDER_SECRET",

    // When true, the backend creates MOCK Razorpay orders (order_mock_...)
    // and the checkout page shows a simulated test-payment dialog instead of
    // the real Razorpay Checkout.js. Set to false AND fill in real keys above
    // to accept real payments. Going live = key swap + mock: false. Nothing else changes.
    mock: true,
  },

  admin: {
    // PLACEHOLDER — change this before going live. The admin panel
    // ( /admin.html ) asks for this password; it is checked server-side.
    password: "changeme123",
  },

  server: {
    port: process.env.PORT || 3000,
    dbFile: process.env.DB_FILE || "./data/app.db",
  },

  delivery: {
    // SAMPLE — delivery charge (INR) applied when the order subtotal is below
    // free_above AND the customer chooses Delivery. Shop Pickup is always free.
    // Default 0 = free delivery until the owner sets a real charge.
    charge: 0,
    free_above: 2000,
  },

  // Heartbeat / live-visitor tuning (seconds)
  live: {
    heartbeatIntervalSec: 15, // frontend pings this often
    staleAfterSec: 45,        // backend treats a visitor as offline after this
  },
};
